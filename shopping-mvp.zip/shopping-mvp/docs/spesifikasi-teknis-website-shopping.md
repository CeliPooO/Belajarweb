# Spesifikasi teknis: website shopping sederhana

Dokumen ini menerjemahkan flow pembeli & admin yang sudah dirancang menjadi data model dan daftar API endpoint yang siap dipakai sebagai prompt/context untuk AI coding agent.

Stack asumsi: Next.js (App Router) + PostgreSQL (misal via Supabase). Sesuaikan tipe data kalau pakai stack lain.

---

## 1. Data model

### users
| Field | Tipe | Catatan |
|---|---|---|
| id | uuid, PK | |
| name | text | |
| email | text, unique | |
| password_hash | text | |
| phone | text | |
| role | enum: customer, admin | |
| created_at | timestamp | |
| updated_at | timestamp | |

### addresses
| Field | Tipe | Catatan |
|---|---|---|
| id | uuid, PK | |
| user_id | uuid, FK → users.id | |
| recipient_name | text | |
| phone | text | |
| address_line | text | |
| city | text | |
| province | text | |
| postal_code | text | dibutuhkan untuk hitung ongkir |
| is_default | boolean | |

### categories
| Field | Tipe |
|---|---|
| id | uuid, PK |
| name | text |
| slug | text, unique |

### products
| Field | Tipe | Catatan |
|---|---|---|
| id | uuid, PK | |
| category_id | uuid, FK → categories.id | |
| name | text | |
| slug | text, unique | |
| description | text | |
| price | integer | simpan dalam rupiah utuh, bukan float |
| stock | integer | |
| weight_grams | integer | wajib, dipakai untuk hitung ongkir |
| is_active | boolean | untuk soft-hide produk |
| created_at / updated_at | timestamp | |

### product_images
| Field | Tipe |
|---|---|
| id | uuid, PK |
| product_id | uuid, FK → products.id |
| url | text |
| sort_order | integer |

### cart_items
| Field | Tipe | Catatan |
|---|---|---|
| id | uuid, PK | |
| user_id | uuid, FK → users.id | atau session_id untuk guest cart |
| product_id | uuid, FK → products.id | |
| qty | integer | |

### orders
| Field | Tipe | Catatan |
|---|---|---|
| id | uuid, PK | |
| order_number | text, unique | human-readable, misal INV-20260904-0001 |
| user_id | uuid, FK → users.id | |
| address_snapshot | jsonb | salin alamat saat order dibuat, jangan reference live ke addresses |
| status | enum | pending_payment, paid, processing, shipped, completed, cancelled |
| subtotal | integer | |
| shipping_cost | integer | |
| total | integer | |
| courier | text | misal "JNE" |
| courier_service | text | misal "REG" |
| tracking_number | text, nullable | diisi saat admin proses kirim |
| payment_method | text, nullable | |
| created_at / updated_at | timestamp | |

### order_items
| Field | Tipe | Catatan |
|---|---|---|
| id | uuid, PK | |
| order_id | uuid, FK → orders.id | |
| product_id | uuid, FK → products.id | |
| product_name_snapshot | text | jaga histori kalau produk berubah nama |
| price_snapshot | integer | |
| qty | integer | |
| subtotal | integer | |

### payments
| Field | Tipe | Catatan |
|---|---|---|
| id | uuid, PK | |
| order_id | uuid, FK → orders.id | |
| provider | text | midtrans / xendit / doku |
| provider_transaction_id | text | |
| amount | integer | |
| status | enum | pending, success, failed, expired |
| payment_type | text | va, ewallet, qris, dll |
| paid_at | timestamp, nullable | |
| raw_payload | jsonb | simpan payload webhook mentah untuk debugging |

### shipments
| Field | Tipe | Catatan |
|---|---|---|
| id | uuid, PK | |
| order_id | uuid, FK → orders.id | |
| tracking_number | text | |
| status | enum | booked, picked_up, in_transit, delivered |
| last_status_update | timestamp | |

---

## 2. API endpoints

### Auth
- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/auth/logout`
- `GET /api/auth/me`

### Produk & kategori (publik)
- `GET /api/products` — list dengan query `?category=&search=&page=`
- `GET /api/products/:slug` — detail produk
- `GET /api/categories`

### Keranjang
- `GET /api/cart`
- `POST /api/cart/items` — body: `{ product_id, qty }`
- `PATCH /api/cart/items/:id` — update qty
- `DELETE /api/cart/items/:id`

### Checkout
- `POST /api/shipping/cost` — body: `{ destination_postal_code, weight_grams }` → return daftar opsi kurir + ongkir
- `POST /api/orders` — buat order dari cart, snapshot item & harga, hitung total
- `POST /api/orders/:id/payment` — buat payment session/link ke payment gateway, return redirect URL/token

### Webhook pembayaran
- `POST /api/webhooks/payment` — didaftarkan ke Midtrans/Xendit. **Wajib** verifikasi signature sebelum update status, supaya endpoint tidak bisa dipalsukan pihak luar

### Order (sisi pembeli)
- `GET /api/orders` — list order milik user login
- `GET /api/orders/:id` — detail order + status + nomor resi

### Admin — produk
- `GET /api/admin/products`
- `POST /api/admin/products`
- `PATCH /api/admin/products/:id`
- `DELETE /api/admin/products/:id`

### Admin — order
- `GET /api/admin/orders` — dengan filter `?status=`
- `GET /api/admin/orders/:id`
- `PATCH /api/admin/orders/:id/status` — update status manual (misal ke "processing")
- `POST /api/admin/orders/:id/ship` — input/generate nomor resi, panggil API kurir untuk booking pengiriman

### Webhook pengiriman (opsional, kalau provider kurir mendukung push update)
- `POST /api/webhooks/shipping` — update status pengiriman otomatis ke tabel shipments & orders

---

## 3. Catatan integrasi penting

- **Payment gateway**: mulai dari sandbox/test keys. Endpoint webhook wajib verifikasi signature (bukan cuma percaya body request) — ini titik paling umum disalahgunakan kalau di-skip.
- **Shipping cost**: dipanggil sinkron saat checkout (butuh respons cepat, user menunggu). Simpan hasil pilihan kurir ke order, jangan hitung ulang setelah order dibuat.
- **Nomor resi**: dibuat saat admin klik "proses kirim", bukan otomatis saat order masuk — order baru berstatus "paid", baru berubah "processing" lalu "shipped" setelah admin bertindak.
- **Role admin**: pisahkan middleware/role check untuk semua endpoint `/api/admin/*` dari endpoint customer biasa.
- **Harga**: simpan sebagai integer (rupiah utuh), hindari tipe float untuk uang.
