# Shopping MVP

Website shopping sederhana -- Next.js (App Router) + Supabase.

Dibangun bertahap. **Tahap ini mencakup:**

1. Setup project & struktur folder
2. Schema database & migrasi untuk `products`, `orders`, `order_items`
3. Halaman katalog produk (publik, belum perlu login)

**Belum dibangun** (menyusul di tahap berikutnya): keranjang, checkout,
kalkulasi ongkir, pembayaran, halaman lacak pesanan, login/auth, dan
seluruh sisi admin. Lihat `docs/spesifikasi-teknis-website-shopping.md`
untuk gambaran lengkap arah proyek.

## Struktur folder

```
shopping-mvp/
├── docs/
│   └── spesifikasi-teknis-website-shopping.md
├── supabase/
│   ├── migrations/0001_init_products_orders.sql
│   └── seed.sql                  # data contoh untuk development
├── src/
│   ├── app/
│   │   ├── page.tsx              # halaman katalog (/)
│   │   ├── error.tsx
│   │   ├── layout.tsx
│   │   ├── globals.css
│   │   └── api/products/route.ts # GET /api/products?search=&page=
│   ├── components/
│   │   ├── ProductCard.tsx
│   │   ├── SearchForm.tsx
│   │   ├── Pagination.tsx
│   │   └── EmptyState.tsx
│   └── lib/
│       ├── config.ts             # nama toko, ukuran halaman
│       ├── format.ts             # format Rupiah
│       ├── types.ts              # tipe TypeScript dari skema DB
│       ├── products.ts           # query produk (dipakai page & API)
│       └── supabase/
│           ├── client.ts         # untuk Client Component (belum dipakai)
│           └── server.ts         # untuk Server Component / Route Handler
└── package.json
```

## Menjalankan di lokal

Butuh Node.js 20+ dan akun [Supabase](https://supabase.com).

### 1. Install dependencies

```bash
npm install
```

### 2. Buat project Supabase & jalankan migrasi

Opsi A -- Supabase CLI (disarankan):

```bash
npx supabase login
npx supabase link --project-ref YOUR-PROJECT-REF
npx supabase db push        # jalankan migrations/0001_init_products_orders.sql
```

Opsi B -- manual: buka **SQL Editor** di dashboard Supabase, paste isi
`supabase/migrations/0001_init_products_orders.sql`, jalankan.

### 3. Isi data contoh (opsional, untuk lihat katalog terisi)

Paste isi `supabase/seed.sql` di SQL Editor, atau `npx supabase db reset`
kalau pakai CLI dengan Supabase lokal (Docker).

### 4. Environment variables

```bash
cp .env.local.example .env.local
```

Isi `NEXT_PUBLIC_SUPABASE_URL` dan `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`
dari **Settings -> API Keys** di dashboard Supabase project kamu. Kalau
dashboard kamu masih menampilkan key lama, key `anon` bisa dipakai di
variabel `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` yang sama -- keduanya
berfungsi sama untuk client Supabase.

### 5. Jalankan dev server

```bash
npm run dev
```

Buka [http://localhost:3000](http://localhost:3000) -- halaman katalog
akan menampilkan produk aktif dari tabel `products`.

## Catatan desain skema (beda dari draft awal)

- `orders.user_id` merujuk ke `auth.users` bawaan Supabase Auth, bukan
  tabel `users` kustom -- supaya tidak reinvent authentication.
- `products.weight_grams` ditambahkan sekarang (bukan di draft awal)
  karena dibutuhkan untuk kalkulasi ongkir otomatis di tahap checkout;
  lebih murah ditambahkan di skema awal daripada migrasi susulan.
- `products.image_url` (satu foto) dipakai dulu untuk MVP, bukan tabel
  `product_images` terpisah dari spesifikasi lengkap. Gampang
  ditingkatkan nanti kalau produk butuh multi-foto.
- Row Level Security sudah aktif di ketiga tabel: `products` bisa dibaca
  publik (hanya yang `is_active = true`), `orders`/`order_items` hanya
  bisa dibaca/dibuat oleh pemiliknya sendiri (`auth.uid() = user_id`).
  Operasi admin (create/update produk, ubah status order) akan pakai
  secret key di tahap admin, jadi belum ada policy write untuk role
  publik/authenticated di luar insert order oleh pemilik.

## Setelah tahap ini

Lanjut ke keranjang & checkout: `cart_items`, endpoint
`POST /api/cart/items`, kalkulasi ongkir, pembuatan order dari cart.
