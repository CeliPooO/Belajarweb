-- seed.sql
-- Data contoh supaya halaman katalog ada isinya saat development.
-- Foto pakai placeholder (placehold.co) -- ganti dengan foto asli /
-- Supabase Storage nanti.
--
-- Jalankan lewat Supabase CLI: supabase db reset (otomatis jalankan
-- seed.sql setelah migrasi), atau paste manual di SQL Editor dashboard.

insert into public.products
  (name, slug, description, price, stock, weight_grams, image_url, is_active)
values
  ('Kemeja Linen Lengan Panjang', 'kemeja-linen-lengan-panjang',
   'Kemeja linen adem, cocok dipakai harian maupun semi-formal.',
   189000, 24, 300, 'https://placehold.co/600x600/1c1b29/fafaf7?text=Kemeja+Linen', true),
  ('Tas Selempang Kanvas', 'tas-selempang-kanvas',
   'Tas selempang kanvas tebal dengan tali kulit sintetis.',
   145000, 15, 450, 'https://placehold.co/600x600/1c1b29/fafaf7?text=Tas+Kanvas', true),
  ('Sepatu Sneakers Putih', 'sepatu-sneakers-putih',
   'Sneakers putih polos, ringan, cocok untuk dipakai sehari-hari.',
   329000, 8, 800, 'https://placehold.co/600x600/1c1b29/fafaf7?text=Sneakers', true),
  ('Jam Tangan Minimalis', 'jam-tangan-minimalis',
   'Jam tangan case tipis dengan tali kulit asli.',
   275000, 0, 150, 'https://placehold.co/600x600/1c1b29/fafaf7?text=Jam+Tangan', true),
  ('Topi Bucket Katun', 'topi-bucket-katun',
   'Bucket hat katun, adem dipakai untuk aktivitas luar ruangan.',
   79000, 40, 120, 'https://placehold.co/600x600/1c1b29/fafaf7?text=Topi+Bucket', true),
  ('Celana Chino Slim Fit', 'celana-chino-slim-fit',
   'Celana chino slim fit, bahan stretch, nyaman dipakai kerja.',
   215000, 18, 400, 'https://placehold.co/600x600/1c1b29/fafaf7?text=Celana+Chino', true),
  ('Dompet Kulit Pria', 'dompet-kulit-pria',
   'Dompet kulit asli dengan slot kartu dan uang tunai.',
   135000, 22, 100, 'https://placehold.co/600x600/1c1b29/fafaf7?text=Dompet+Kulit', true),
  ('Kacamata Hitam Klasik', 'kacamata-hitam-klasik',
   'Kacamata hitam dengan lensa UV protection, bingkai klasik.',
   99000, 30, 90, 'https://placehold.co/600x600/1c1b29/fafaf7?text=Kacamata', true),
  ('Sandal Slide Karet', 'sandal-slide-karet',
   'Sandal slide karet, empuk, cocok untuk santai di rumah.',
   65000, 50, 250, 'https://placehold.co/600x600/1c1b29/fafaf7?text=Sandal+Slide', true),
  ('Produk Nonaktif (contoh)', 'produk-nonaktif-contoh',
   'Contoh produk yang di-nonaktifkan -- tidak akan muncul di katalog.',
   50000, 5, 200, 'https://placehold.co/600x600/1c1b29/fafaf7?text=Nonaktif', false);
