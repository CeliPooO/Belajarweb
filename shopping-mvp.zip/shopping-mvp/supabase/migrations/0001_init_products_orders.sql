-- 0001_init_products_orders.sql
--
-- Tahap 1 MVP: skema untuk products, orders, order_items.
-- Tabel lain dari spesifikasi (categories, addresses, product_images,
-- payments, shipments, dst.) sengaja belum dibuat -- menyusul di tahap
-- keranjang/checkout & admin.
--
-- Catatan desain yang berbeda dari draft data model awal:
--  - orders.user_id merujuk ke auth.users (bawaan Supabase Auth), bukan
--    tabel users kustom -- karena auth ditangani oleh Supabase.
--  - products.weight_grams ditambahkan sekarang (default 0) karena
--    dibutuhkan nanti untuk kalkulasi ongkir otomatis; lebih murah
--    ditambahkan di sini daripada migrasi susulan.
--  - products.image_url (satu foto) dipakai dulu untuk MVP, bukan tabel
--    product_images terpisah. Gampang dinaikkan levelnya nanti kalau
--    produk butuh multi-foto.

create extension if not exists "pgcrypto";

-- =========================================================
-- products
-- =========================================================
create table public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  description text,
  price integer not null check (price >= 0), -- rupiah utuh, bukan float
  stock integer not null default 0 check (stock >= 0),
  weight_grams integer not null default 0 check (weight_grams >= 0),
  image_url text,
  is_active boolean not null default true, -- soft-hide produk
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index products_is_active_idx on public.products (is_active);

-- =========================================================
-- orders
-- =========================================================
create type public.order_status as enum (
  'pending_payment',
  'paid',
  'processing',
  'shipped',
  'completed',
  'cancelled'
);

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  order_number text not null unique, -- misal INV-20260904-0001
  user_id uuid not null references auth.users (id) on delete restrict,
  shipping_address jsonb not null, -- snapshot alamat saat order dibuat
  status public.order_status not null default 'pending_payment',
  subtotal integer not null check (subtotal >= 0),
  shipping_cost integer not null default 0 check (shipping_cost >= 0),
  total integer not null check (total >= 0),
  courier text,
  courier_service text,
  tracking_number text, -- nomor resi, diisi admin saat proses kirim
  payment_method text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index orders_user_id_idx on public.orders (user_id);
create index orders_status_idx on public.orders (status);

-- =========================================================
-- order_items
-- =========================================================
create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders (id) on delete cascade,
  product_id uuid not null references public.products (id) on delete restrict,
  product_name_snapshot text not null,
  price_snapshot integer not null check (price_snapshot >= 0),
  qty integer not null check (qty > 0),
  subtotal integer not null check (subtotal >= 0)
);

create index order_items_order_id_idx on public.order_items (order_id);
create index order_items_product_id_idx on public.order_items (product_id);

-- =========================================================
-- updated_at trigger
-- =========================================================
create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger products_set_updated_at
  before update on public.products
  for each row execute function public.set_updated_at();

create trigger orders_set_updated_at
  before update on public.orders
  for each row execute function public.set_updated_at();

-- =========================================================
-- Row Level Security
-- =========================================================
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;

-- Produk aktif boleh dibaca siapa saja (katalog publik, belum perlu login).
create policy "Public can read active products"
  on public.products for select
  using (is_active = true);

-- Menulis produk (admin) akan pakai secret key (bypass RLS) di tahap
-- admin nanti, jadi belum ada policy insert/update/delete di sini.

-- Order hanya boleh dilihat/dibuat oleh pemiliknya sendiri.
create policy "Users can view own orders"
  on public.orders for select
  using (auth.uid() = user_id);

create policy "Users can create own orders"
  on public.orders for insert
  with check (auth.uid() = user_id);

-- Update status/resi oleh admin akan lewat secret key di tahap admin.

-- order_items ikut visibility order induknya.
create policy "Users can view own order items"
  on public.order_items for select
  using (
    exists (
      select 1 from public.orders o
      where o.id = order_items.order_id
        and o.user_id = auth.uid()
    )
  );

create policy "Users can create own order items"
  on public.order_items for insert
  with check (
    exists (
      select 1 from public.orders o
      where o.id = order_items.order_id
        and o.user_id = auth.uid()
    )
  );
