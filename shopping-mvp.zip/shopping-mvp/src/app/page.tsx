import { getProducts } from "@/lib/products";
import { SHOP_NAME } from "@/lib/config";
import { ProductCard } from "@/components/ProductCard";
import { SearchForm } from "@/components/SearchForm";
import { Pagination } from "@/components/Pagination";
import { EmptyState } from "@/components/EmptyState";

interface CatalogPageProps {
  searchParams: Promise<{ search?: string; page?: string }>;
}

export default async function CatalogPage({ searchParams }: CatalogPageProps) {
  const params = await searchParams;
  const search = params.search?.trim() || undefined;
  const page = Number(params.page ?? "1") || 1;

  const { products, totalPages, totalCount } = await getProducts({
    search,
    page,
  });

  return (
    <main className="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:px-8">
      <header className="flex flex-col gap-4 border-b border-border pb-6 sm:flex-row sm:items-end sm:justify-between">
        <h1 className="font-display text-3xl text-ink">{SHOP_NAME}</h1>
        <SearchForm initialSearch={search} />
      </header>

      <p className="pt-6 text-sm text-ink-soft">
        Menampilkan {products.length} dari {totalCount} produk
      </p>

      {products.length === 0 ? (
        <EmptyState search={search} />
      ) : (
        <div className="grid grid-cols-2 gap-4 pt-4 sm:grid-cols-3 lg:grid-cols-4">
          {products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      )}

      <Pagination page={page} totalPages={totalPages} search={search} />
    </main>
  );
}
