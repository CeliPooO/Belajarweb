import { NextRequest, NextResponse } from "next/server";
import { getProducts } from "@/lib/products";

// GET /api/products?search=&page=
// Catatan: query "?category=" dari spesifikasi belum diimplementasikan --
// menyusul saat tabel categories dibuat di tahap berikutnya.
export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const search = searchParams.get("search") ?? undefined;
  const page = Number(searchParams.get("page") ?? "1") || 1;

  try {
    const result = await getProducts({ search, page });
    return NextResponse.json(result);
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
