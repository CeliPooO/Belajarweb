"use client";

export default function CatalogError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <main className="mx-auto flex max-w-2xl flex-col gap-4 px-4 py-16 text-center">
      <h1 className="font-display text-2xl text-ink">
        Katalog tidak bisa dimuat
      </h1>
      <p className="text-sm text-ink-soft">
        Kemungkinan penyebab: variabel lingkungan Supabase belum diisi di
        <code className="mx-1 rounded-sm bg-white px-1 py-0.5">
          .env.local
        </code>
        , atau migrasi database belum dijalankan.
      </p>
      <p className="text-xs text-ink-soft">{error.message}</p>
      <button
        onClick={reset}
        className="mx-auto rounded-md border border-border px-4 py-2 text-sm text-ink hover:border-accent hover:text-accent-deep"
      >
        Coba lagi
      </button>
    </main>
  );
}
