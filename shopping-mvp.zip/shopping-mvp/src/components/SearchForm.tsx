export function SearchForm({ initialSearch }: { initialSearch?: string }) {
  return (
    <form action="/" method="GET" className="w-full sm:w-72">
      <label htmlFor="search" className="sr-only">
        Cari produk
      </label>
      <input
        id="search"
        name="search"
        type="search"
        defaultValue={initialSearch}
        placeholder="Cari produk..."
        className="w-full rounded-md border border-border bg-white px-3 py-2 text-sm text-ink placeholder:text-ink-soft focus:border-accent focus:outline-none focus:ring-1 focus:ring-accent"
      />
    </form>
  );
}
