export function EmptyState({ search }: { search?: string }) {
  return (
    <div className="flex flex-col items-center gap-2 rounded-md border border-dashed border-border py-16 text-center">
      <p className="font-sans text-base text-ink">
        {search
          ? `Tidak ada produk yang cocok dengan "${search}".`
          : "Belum ada produk."}
      </p>
      {search && (
        <a href="/" className="text-sm text-accent-deep hover:underline">
          Reset pencarian
        </a>
      )}
    </div>
  );
}
