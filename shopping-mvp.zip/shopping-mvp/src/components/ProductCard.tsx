import Image from "next/image";
import { formatRupiah } from "@/lib/format";
import type { Product } from "@/lib/types";

export function ProductCard({ product }: { product: Product }) {
  const outOfStock = product.stock <= 0;

  return (
    <article className="flex flex-col overflow-hidden rounded-md border border-border bg-white">
      <div className="relative aspect-square bg-paper">
        {product.image_url ? (
          <Image
            src={product.image_url}
            alt={product.name}
            fill
            sizes="(min-width: 1024px) 25vw, (min-width: 640px) 33vw, 50vw"
            className={`object-cover ${outOfStock ? "grayscale opacity-60" : ""}`}
          />
        ) : (
          <div className="flex h-full items-center justify-center text-sm text-ink-soft">
            Tidak ada foto
          </div>
        )}
        {outOfStock && (
          <span className="absolute left-2 top-2 rounded-sm bg-ink px-2 py-1 text-xs font-medium text-paper">
            Stok habis
          </span>
        )}
      </div>
      <div className="flex flex-1 flex-col gap-1 p-4">
        <h3 className="text-sm text-ink-soft">{product.name}</h3>
        <p className="mt-auto font-sans text-lg font-semibold tabular-nums text-accent-deep">
          {formatRupiah(product.price)}
        </p>
      </div>
    </article>
  );
}
