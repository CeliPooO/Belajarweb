interface PaginationProps {
  page: number;
  totalPages: number;
  search?: string;
}

function buildHref(page: number, search?: string) {
  const params = new URLSearchParams();
  if (search) params.set("search", search);
  if (page > 1) params.set("page", String(page));
  const query = params.toString();
  return query ? `/?${query}` : "/";
}

export function Pagination({ page, totalPages, search }: PaginationProps) {
  if (totalPages <= 1) return null;

  const hasPrev = page > 1;
  const hasNext = page < totalPages;

  return (
    <nav
      className="flex items-center justify-center gap-4 pt-4"
      aria-label="Navigasi halaman"
    >
      {hasPrev ? (
        <a
          href={buildHref(page - 1, search)}
          className="rounded-md border border-border px-3 py-1.5 text-sm text-ink hover:border-accent hover:text-accent-deep"
        >
          Sebelumnya
        </a>
      ) : (
        <span className="px-3 py-1.5 text-sm text-ink-soft opacity-50">
          Sebelumnya
        </span>
      )}

      <span className="text-sm text-ink-soft">
        Halaman {page} dari {totalPages}
      </span>

      {hasNext ? (
        <a
          href={buildHref(page + 1, search)}
          className="rounded-md border border-border px-3 py-1.5 text-sm text-ink hover:border-accent hover:text-accent-deep"
        >
          Berikutnya
        </a>
      ) : (
        <span className="px-3 py-1.5 text-sm text-ink-soft opacity-50">
          Berikutnya
        </span>
      )}
    </nav>
  );
}
