const rupiahFormatter = new Intl.NumberFormat("id-ID", {
  style: "currency",
  currency: "IDR",
  minimumFractionDigits: 0,
  maximumFractionDigits: 0,
});

/** Format harga integer (rupiah utuh) jadi string "Rp150.000". */
export function formatRupiah(amount: number): string {
  return rupiahFormatter.format(amount);
}
