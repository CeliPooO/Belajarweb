import { createClient } from "@/lib/supabase/server";
import { PRODUCTS_PER_PAGE } from "@/lib/config";
import type { Product } from "@/lib/types";

export interface GetProductsParams {
  search?: string;
  page?: number;
}

export interface GetProductsResult {
  products: Product[];
  page: number;
  totalPages: number;
  totalCount: number;
}

/**
 * Ambil produk aktif untuk katalog publik. RLS pada tabel products
 * sudah membatasi hasil ke is_active = true, filter di sini cuma untuk
 * kejelasan query.
 */
export async function getProducts({
  search,
  page = 1,
}: GetProductsParams): Promise<GetProductsResult> {
  const supabase = await createClient();
  const currentPage = Math.max(1, page);
  const from = (currentPage - 1) * PRODUCTS_PER_PAGE;
  const to = from + PRODUCTS_PER_PAGE - 1;

  let query = supabase
    .from("products")
    .select("*", { count: "exact" })
    .eq("is_active", true)
    .order("created_at", { ascending: false })
    .range(from, to);

  if (search && search.trim().length > 0) {
    query = query.ilike("name", `%${search.trim()}%`);
  }

  const { data, error, count } = await query;

  if (error) {
    throw new Error(`Gagal mengambil produk: ${error.message}`);
  }

  const totalCount = count ?? 0;
  const totalPages = Math.max(1, Math.ceil(totalCount / PRODUCTS_PER_PAGE));

  return {
    products: (data ?? []) as Product[],
    page: currentPage,
    totalPages,
    totalCount,
  };
}
