// Ganti nilai-nilai ini sesuai kebutuhan toko.
export const SHOP_NAME = "Etalase";
export const PRODUCTS_PER_PAGE = 12;
