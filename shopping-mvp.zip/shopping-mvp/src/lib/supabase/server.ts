import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";

/**
 * Supabase client untuk dipakai di Server Component / Route Handler.
 * Pakai publishable key (client-safe) -- RLS tetap berlaku, jadi aman
 * dipanggil dari sisi server untuk data publik seperti katalog produk.
 */
export async function createClient() {
  const cookieStore = await cookies();

  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY!,
    {
      cookies: {
        getAll() {
          return cookieStore.getAll();
        },
        setAll(cookiesToSet) {
          try {
            cookiesToSet.forEach(({ name, value, options }) =>
              cookieStore.set(name, value, options),
            );
          } catch {
            // Dipanggil dari Server Component tanpa akses tulis cookie --
            // aman diabaikan selama middleware/session refresh ada di
            // tahap auth nanti.
          }
        },
      },
    },
  );
}
