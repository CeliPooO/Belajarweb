import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  images: {
    // Add your Supabase Storage project domain here once product photos
    // move to Supabase Storage, e.g. "xyzcompany.supabase.co".
    remotePatterns: [
      { protocol: "https", hostname: "placehold.co" },
    ],
  },
};

export default nextConfig;
